<html>
<head> <title> Шарафиева Ксения </title> </head>
<body style=" background-color:#FFFFCC">
<H2>Добавление машины:</H2>
<form action="save_new.php" metod="get">
 Марка: <input name="name" size="50" type="text">
<br>Модель: <input name="model" size="20" type="text">
<br>Год выпуска: <input name="year" size="20" type="text">
<br>Трансмиссия: <input name="trans" size="30" type="text">
<br>Объем выпуска: <input name="value" size="30" type="text">
<br>Цена: <input name="cost" size="30" type="text">
<p><input name="add" type="submit" value="Добавить">
<input name="b2" type="reset" value="Очистить"></p>
</form>
<p>
<a href="index.php"> Вернуться к списку машин </a>
</body>
</html>