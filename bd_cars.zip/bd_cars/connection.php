<?php
$host = "localhost"; // адрес сервера 
$port=3306;
$database = "cars"; // имя базы данных
$user = "kseniya"; // имя пользователя
$password = "1234"; // пароль
?>